NOIR
====

Luxury automotive website with:
- Scroll-based hero animation
- Model and gallery image switching
- Live automotive news through a server-side GNews proxy
- Test drive contact form
- NOIR test-drive chatbot
- Google Sheets booking storage

SETUP
-----

1. Install Node.js 18 or newer.
2. Keep the `.env` file in the project folder and add your GNews key:
   GNEWS_API_KEY=YOUR_GNEWS_API_KEY
3. Open Command Prompt in this folder.
4. Run:
   npm start
5. Open:
   http://localhost:3000

Do not open `index.html` directly and do not use VS Code Live Server. The news section needs the Node.js server.

GITHUB
------

`.env` is ignored by Git and should not be uploaded.

TEST DRIVE CHATBOT
------------------

The chatbot sends bookings to Google Sheets.

Google Sheet columns:
Booking ID | Timestamp | Customer Name | Phone | Email | Model | Preferred Date | Preferred Time | Location | Status

To connect the chatbot:

1. Create a Google Sheet.
2. Open Extensions > Apps Script.
3. Paste the contents of `NOIR_Google_Apps_Script.gs`.
4. Deploy it as a Web app.
5. Execute as: Me.
6. Allow access to anyone who should be able to submit a booking.
7. Copy the Web App URL.
8. Put that URL in `main.js` as `GOOGLE_SHEETS_URL`.

The chatbot supports creating and cancelling bookings.

FILES
-----

`server.js`      Local server and GNews proxy
`main.js`        Website interactions and chatbot
`news.js`        News display
`style.css`      Website and chatbot styling
`index.html`     Website structure
`NOIR_Google_Apps_Script.gs`  Google Sheets booking backend
