

gsap.registerPlugin(ScrollTrigger, ScrollToPlugin);

const canvas = document.getElementById("hero-lightpass");
const context = canvas.getContext("2d");

const frameCount = 217;

const currentFrame = (index) =>
    `frames/ezgif-frame-${String(index).padStart(3, "0")}.jpg`;

const images = [];

const animation = {
    frame: 1
};

for (let i = 1; i <= frameCount; i++) {

    const img = new Image();

    img.src = currentFrame(i);

    images.push(img);

}

function resizeCanvas() {

    canvas.width = window.innerWidth;

    canvas.height = window.innerHeight;

    render();

}

window.addEventListener("resize", resizeCanvas);

function render() {

    let index = animation.frame - 1;

    while (index > 0 && (!images[index] || !images[index].complete)) {
        index--;
    }

    const image = images[index];

    if (!image || !image.complete) return;

    context.clearRect(0, 0, canvas.width, canvas.height);

    const hRatio = canvas.width / image.width;

    const vRatio = canvas.height / image.height;

    const ratio = Math.max(hRatio, vRatio);

    const centerShiftX =
        (canvas.width - image.width * ratio) / 2;

    const centerShiftY =
        (canvas.height - image.height * ratio) / 2;

    context.drawImage(

        image,

        0,

        0,

        image.width,

        image.height,

        centerShiftX,

        centerShiftY,

        image.width * ratio,

        image.height * ratio

    );

}

images[0].onload = () => {

    resizeCanvas();

};

gsap.to(animation, {

    frame: frameCount,

    snap: "frame",

    ease: "none",

    scrollTrigger: {

        trigger: ".hero",

        start: "top top",

        end: "+=3500",

        pin: true,

        scrub: 0.5,

        anticipatePin: 1,

        fastScrollEnd: true

    },

    onUpdate: render

});

gsap.from(".hero-tag", {

    y: 80,

    opacity: 0,

    duration: 1,

    delay: 0.3

});

gsap.from(".hero-content h1", {

    y: 100,

    opacity: 0,

    duration: 1.2,

    delay: 0.5

});

gsap.from(".hero-content p", {

    y: 80,

    opacity: 0,

    duration: 1,

    delay: 0.8

});

gsap.from(".hero-buttons", {

    y: 60,

    opacity: 0,

    duration: 1,

    delay: 1

});

window.addEventListener("scroll", () => {

    const navbar = document.querySelector(".navbar");

    navbar.classList.toggle("scrolled", window.scrollY > 50);

});

document.querySelectorAll('a[href^="#"]').forEach((link) => {

    link.addEventListener("click", (e) => {

        const targetId = link.getAttribute("href");

        if (!targetId || targetId.length < 2) return; // skip bare "#" placeholders

        const target = document.querySelector(targetId);

        if (!target) return;

        e.preventDefault();

        gsap.to(window, {
            duration: 1,
            scrollTo: { y: target, offsetY: 90 },
            ease: "power2.inOut"
        });

    });

});

gsap.utils.toArray("section").forEach((section) => {

    if (section.classList.contains("hero")) return;

    gsap.from(section, {

        opacity: 0,

        y: 120,

        duration: 1,

        ease: "power3.out",

        scrollTrigger: {

            trigger: section,

            start: "top 80%"

        }

    });

});

gsap.from(".model-card", {

    y: 120,

    opacity: 0,

    duration: 1,

    stagger: 0.2,

    ease: "power3.out",

    scrollTrigger: {

        trigger: ".models",

        start: "top 70%"

    }

});

gsap.set(".section-title", {
    opacity: 1,
    clearProps: "all"
});

gsap.from(".section-title", {
    y: 60,
    opacity: 0,
    duration: 1,
    ease: "power3.out",
    scrollTrigger: {
        trigger: "#technology",
        start: "top 80%"
    }
});

document.querySelectorAll(".stat-box h2").forEach((stat) => {

    gsap.from(stat, {

        innerText: 0,

        duration: 2,

        snap: { innerText: 1 },

        ease: "power2.out",

        scrollTrigger: {

            trigger: ".stats",

            start: "top 75%"

        }

    });

});
document.addEventListener("DOMContentLoaded", () => {

    const cards = document.querySelectorAll(".model-card");

    cards.forEach(card => {

        const image = card.querySelector("img");

        const galleryImages = JSON.parse(card.dataset.images);

        let current = 0;

        card.addEventListener("click", (e) => {

            const rect = card.getBoundingClientRect();
            const x = e.clientX - rect.left;

            image.style.opacity = "0";

            setTimeout(() => {

                if (x < rect.width / 2) {
                    current = (current - 1 + galleryImages.length) % galleryImages.length;
                } else {
                    current = (current + 1) % galleryImages.length;
                }

                image.src = galleryImages[current];

                image.style.opacity = "1";

            }, 150);

        });

    });

});
const performance = document.querySelector(".performance-right");

if (performance) {

    const image = performance.querySelector("img");
    const galleryImages = JSON.parse(performance.dataset.images);

    let current = 0;

    performance.addEventListener("click", (e) => {

        const rect = performance.getBoundingClientRect();
        const x = e.clientX - rect.left;

        image.style.opacity = "0";

        setTimeout(() => {

            if (x < rect.width / 2) {
                current = (current - 1 + galleryImages.length) % galleryImages.length;
            } else {
                current = (current + 1) % galleryImages.length;
            }

            image.src = galleryImages[current];
            image.style.opacity = "1";

        }, 150);

    });

}

document.querySelectorAll(".gallery-item").forEach(item => {

    const image = item.querySelector("img");
    const galleryImages = JSON.parse(item.dataset.images);

    let current = 0;

    item.addEventListener("click", (e) => {

        const rect = item.getBoundingClientRect();
        const x = e.clientX - rect.left;

        image.style.opacity = "0";

        setTimeout(() => {

            if (x < rect.width / 2) {
                current = (current - 1 + galleryImages.length) % galleryImages.length;
            } else {
                current = (current + 1) % galleryImages.length;
            }

            image.src = galleryImages[current];

            image.style.opacity = "1";

        }, 150);

    });

});

const contactForm = document.getElementById("contact-form");
const formSuccess = document.getElementById("form-success");

if (contactForm) {

    contactForm.addEventListener("submit", (e) => {

        e.preventDefault();

        if (!contactForm.checkValidity()) {
            contactForm.reportValidity();
            return;
        }

        formSuccess.classList.add("visible");
        contactForm.reset();

    });

}

document.addEventListener("DOMContentLoaded", () => {
    const chatToggle = document.getElementById("noir-chat-toggle");
    const chatWindow = document.getElementById("noir-chat-window");
    const chatClose = document.getElementById("noir-chat-close");
    const messages = document.getElementById("noir-chat-messages");
    const input = document.getElementById("noir-chat-input");
    const send = document.getElementById("noir-chat-send");
    const badge = document.querySelector(".noir-chat-badge");

    if (!chatToggle || !chatWindow || !messages || !input || !send) return;

    const GOOGLE_SHEETS_URL = "https://script.google.com/macros/s/AKfycbweQvWLW626RILD-Hx3lBaCGPcq3JGqoX19Wdg6qfpyPwwPW7ljFqpVM2TtVuugWkDYlA/exec";

    const booking = {
        bookingId: "",
        name: "",
        phone: "",
        email: "",
        model: "",
        date: "",
        time: "",
        location: ""
    };

    let step = "start";

    const addMessage = (text, sender = "bot") => {
        const bubble = document.createElement("div");
        bubble.className = `noir-message ${sender}`;
        bubble.textContent = text;
        messages.appendChild(bubble);
        messages.scrollTop = messages.scrollHeight;
    };

    const addChoices = (choices) => {
        const wrapper = document.createElement("div");
        wrapper.className = "noir-chat-choices";

        choices.forEach(choice => {
            const button = document.createElement("button");
            button.type = "button";
            button.textContent = choice;
            button.addEventListener("click", () => {
                wrapper.remove();
                handleInput(choice);
            });
            wrapper.appendChild(button);
        });

        messages.appendChild(wrapper);
        messages.scrollTop = messages.scrollHeight;
    };

    const addTyping = () => {
        const typing = document.createElement("div");
        typing.className = "noir-message bot noir-typing";
        typing.innerHTML = "<span></span><span></span><span></span>";
        messages.appendChild(typing);
        messages.scrollTop = messages.scrollHeight;
        return typing;
    };

    const botReply = (text, delay = 450) => {
        const typing = addTyping();
        setTimeout(() => {
            typing.remove();
            addMessage(text, "bot");
        }, delay);
    };

    const isValidEmail = value =>
        /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);

    const isValidPhone = value =>
        /^[0-9+\-\s]{8,15}$/.test(value);

    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const isValidDate = value => {
        const selected = new Date(value + "T00:00:00");
        return !Number.isNaN(selected.getTime()) && selected >= today;
    };

    const sendBooking = async () => {
        if (!GOOGLE_SHEETS_URL ||
            GOOGLE_SHEETS_URL === "PASTE_YOUR_GOOGLE_APPS_SCRIPT_WEB_APP_URL_HERE") {
            return { ok: false, setup: true };
        }

        try {
            const response = await fetch(GOOGLE_SHEETS_URL, {
                method: "POST",
                mode: "cors",
                headers: {
                    "Content-Type": "text/plain;charset=utf-8"
                },
                body: JSON.stringify({
                    action: "create",
                    ...booking,
                    status: "Pending"
                })
            });

            if (!response.ok) throw new Error("Booking request failed");

            const result = await response.json();

            if (!result.success) {
                throw new Error(result.error || "Booking failed");
            }

            booking.bookingId = result.bookingId;

            return { ok: true };

        } catch (error) {
            console.error("NOIR booking error:", error);
            return { ok: false, setup: false };
        }
    };

    const startChat = () => {
        messages.innerHTML = "";
        step = "start";

        Object.keys(booking).forEach(key => booking[key] = "");

        if (badge) badge.style.display = "none";

        addMessage("Welcome to NOIR. I'm your test drive concierge.");
        setTimeout(() => {
            addMessage("Would you like to book a test drive?");
            addChoices(["Yes, book a test drive", "Not right now"]);
        }, 500);
    };

    const handleInput = async (value) => {
        const answer = value.trim();
        if (!answer) return;

        if (
            answer.toLowerCase() === "cancel" ||
            answer.toLowerCase() === "cancel booking"
        ) {
            addMessage(answer, "user");

            if (booking.bookingId) {
                try {
                    const response = await fetch(GOOGLE_SHEETS_URL, {
                        method: "POST",
                        mode: "cors",
                        headers: {
                            "Content-Type": "text/plain;charset=utf-8"
                        },
                        body: JSON.stringify({
                            action: "cancel",
                            bookingId: booking.bookingId
                        })
                    });

                    const result = await response.json();

                    if (result.success) {
                        botReply("Your booking has been cancelled successfully.");
                    } else {
                        botReply("Sorry, I couldn't cancel your booking.");
                    }

                } catch (error) {
                    botReply("Sorry, I couldn't cancel your booking.");
                }

            } else {
                botReply("There is no confirmed booking to cancel.");
            }

            return;
        }
    
        addMessage(answer, "user");

        if (step === "start") {
            if (answer === "Not right now") {
                botReply("No problem. I'm here whenever you're ready.");
                setTimeout(() => {
                    addChoices(["Book a test drive"]);
                }, 500);
                step = "waiting";
                return;
        }
            step = "name";
            botReply("Great. May I have your full name?");
            return;
        }

        if (step === "name") {
            booking.name = answer;
            step = "phone";
            botReply("Thanks. What is the best phone number to reach you?");
            return;
        }

        if (step === "phone") {
            if (!isValidPhone(answer)) {
                botReply("Please enter a valid phone number.");
                return;
            }
            booking.phone = answer;
            step = "email";
            botReply("And your email address?");
            return;
        }

        if (step === "email") {
            if (!isValidEmail(answer)) {
                botReply("That doesn't look like a valid email. Please try again.");
                return;
            }
            booking.email = answer;
            step = "model";
            botReply("Which NOIR model would you like to drive?");
            setTimeout(() => addChoices(["Porsche 911", "Rolls Royce", "LaFerrari"]), 450);
            return;
        }

        if (step === "model") {
            const models = ["Porsche 911", "Rolls Royce", "LaFerrari"];
            if (!models.includes(answer)) {
                botReply("Please choose one of the available models.");
                return;
            }
            booking.model = answer;
            step = "date";
            botReply("What date would you prefer? Please use YYYY-MM-DD.");
            return;
        }

        if (step === "date") {
            if (!/^\d{4}-\d{2}-\d{2}$/.test(answer) || !isValidDate(answer)) {
                botReply("Please enter a valid future date in YYYY-MM-DD format.");
                return;
            }
            booking.date = answer;
            step = "time";
            botReply("What time would you prefer? For example, 3:00 PM.");
            return;
        }

        if (step === "time") {
            booking.time = answer;
            step = "location";
            botReply("Which location would you prefer for the test drive?");
            return;
        }

        if (step === "location") {
            booking.location = answer;
            step = "confirm";

            setTimeout(() => {
                addMessage("Please review your booking details:");
                addMessage(
                    `Name: ${booking.name}\n` +
                    `Phone: ${booking.phone}\n` +
                    `Email: ${booking.email}\n` +
                    `Model: ${booking.model}\n` +
                    `Date: ${booking.date}\n` +
                    `Time: ${booking.time}\n` +
                    `Location: ${booking.location}`
                );
                addChoices(["Confirm booking", "Start over"]);
            }, 450);
            return;
        }

        if (step === "confirm") {
            if (answer === "Start over") {
                startChat();
                return;
            }

            if (answer === "Confirm booking") {
                step = "saving";
                const typing = addTyping();

                sendBooking().then(result => {
                    typing.remove();

                    if (result.setup) {
                        addMessage("The chatbot is ready, but the Google Sheet connection still needs to be configured.");
                    } else if (!result.ok) {
                        addMessage("I couldn't save the appointment right now. Please try again or use the contact form.");
                    } else {
                        addMessage(
                            `Booking request received. Thank you, ${booking.name}. We'll contact you shortly to confirm your ${booking.model} test drive.`
                        );
                    }

                    addChoices(["Book another test drive", "Close"]);
                    step = "done";
                });
                return;
            }
        }

        if (step === "waiting") {
            if (answer === "Book a test drive") {
                startChat();
            }
            return;
        }

        if (step === "done") {
            if (answer === "Book another test drive") startChat();
            if (answer === "Close") chatWindow.classList.remove("open");
        }
    };

    chatToggle.addEventListener("click", () => {
        chatWindow.classList.toggle("open");
        if (chatWindow.classList.contains("open") && messages.children.length === 0) {
            startChat();
        }
    });

    chatClose.addEventListener("click", () => chatWindow.classList.remove("open"));

    send.addEventListener("click", () => {
        const value = input.value;
        input.value = "";
        handleInput(value);
    });

    input.addEventListener("keydown", event => {
        if (event.key === "Enter") {
            const value = input.value;
            input.value = "";
            handleInput(value);
        }
    });
});
