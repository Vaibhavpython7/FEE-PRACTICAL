function doPost(e) {
  try {
    const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheets()[0];
    const data = JSON.parse(e.postData.contents || "{}");

    if (data.action === "cancel") {
      const values = sheet.getDataRange().getValues();
      const bookingId = String(data.bookingId || "").trim();

      for (let i = 1; i < values.length; i++) {
        if (String(values[i][0]).trim() === bookingId) {
          sheet.getRange(i + 1, 10).setValue("Cancelled");
          return jsonResponse({
            success: true,
            bookingId: bookingId,
            status: "Cancelled"
          });
        }
      }

      return jsonResponse({
        success: false,
        error: "Booking ID not found."
      });
    }

    const bookingId =
      "NOIR-" + Utilities.getUuid().substring(0, 8).toUpperCase();

    sheet.appendRow([
      bookingId,
      new Date(),
      data.name || "",
      data.phone || "",
      data.email || "",
      data.model || "",
      data.date || "",
      data.time || "",
      data.location || "",
      data.status || "Pending"
    ]);

    return jsonResponse({
      success: true,
      bookingId: bookingId
    });
  } catch (error) {
    return jsonResponse({
      success: false,
      error: error.toString()
    });
  }
}

function jsonResponse(data) {
  return ContentService
    .createTextOutput(JSON.stringify(data))
    .setMimeType(ContentService.MimeType.JSON);
}
