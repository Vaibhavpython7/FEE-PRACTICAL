const image = document.getElementById("news-image");
const title = document.getElementById("news-title");
const description = document.getElementById("news-description");
const source = document.getElementById("news-source");
const date = document.getElementById("news-date");
const link = document.getElementById("news-link");
const progress = document.querySelector(".news-progress-bar");

const fallbackImage = "Images/download_(1).jpg_2K_202607301024.jpeg";

function showFallback(message) {
    image.src = fallbackImage;
    image.alt = "Automotive News";
    title.textContent = message;
    description.textContent = "Please check your GNews API key and server connection.";
    source.textContent = "";
    date.textContent = "";
    link.style.display = "none";
    progress.style.width = "0";
}

fetch("/api/news")
    .then(async res => {
        let data;

        try {
            data = await res.json();
        } catch {
            throw new Error(`Server returned HTTP ${res.status}`);
        }

        if (!res.ok) {
            throw new Error(data.error || `News API returned HTTP ${res.status}`);
        }

        return data;
    })
    .then(data => {
        const articles = data.articles;

        if (!articles || articles.length === 0) {
            showFallback("No automotive news available right now.");
            return;
        }

        let current = 0;

        function showArticle(index) {
            const article = articles[index];

            image.onerror = () => {
                image.onerror = null;
                image.src = fallbackImage;
            };
            image.src = article.image || fallbackImage;
            image.alt = article.title || "Automotive News";

            title.textContent = article.title || "Latest automotive news";

            description.textContent =
                article.description || "Read the latest automotive news.";

            source.textContent = article.source?.name || "GNews";

            date.textContent = article.publishedAt
                ? new Date(article.publishedAt).toLocaleDateString("en-GB", {
                    day: "2-digit",
                    month: "short",
                    year: "numeric"
                })
                : "";

            if (article.url) {
                link.href = article.url;
                link.style.display = "inline-flex";
            } else {
                link.style.display = "none";
            }

            progress.style.transition = "none";
            progress.style.width = "0";

            setTimeout(() => {
                progress.style.transition = "width 5s linear";
                progress.style.width = "100%";
            }, 70);
        }

        showArticle(current);

        setInterval(() => {
            current = (current + 1) % articles.length;
            showArticle(current);
        }, 5000);
    })
    .catch(err => {
        console.error("News API error:", err);
        showFallback("Couldn't load automotive news right now.");
    });
